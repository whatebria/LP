
package clases;

import java.util.ArrayList;

public class Repositorio {
    private ArrayList <Publicacion> publicaciones = new ArrayList<>();

    public void add(Publicacion publicacion){
        publicaciones.add(publicacion);
    }
    
    public  ArrayList<Publicacion> getPublicaciones(){
        return publicaciones;
    }
    
    public ArrayList<Publicacion> getPublicacionensByEstado(Estado estado){
        ArrayList<Publicacion> listaPublicaciones = new ArrayList<>();
        for(Publicacion publis : publicaciones){
            if(publis.getEstado() == estado){
                listaPublicaciones.add(publis);
            }
        }
        return listaPublicaciones;
    }
    public ArrayList<Publicacion> getPublicacionensByAño(int año){
        ArrayList<Publicacion> listaPublicaciones = new ArrayList<>();
        for(Publicacion publis : publicaciones){
            if(publis.getAño() == año){
                listaPublicaciones.add(publis);
            }
        }
        return listaPublicaciones;
    }
}
