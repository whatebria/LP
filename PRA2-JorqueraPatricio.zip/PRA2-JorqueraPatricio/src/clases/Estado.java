
package clases;

public enum Estado {
    Pendiente, Autorizada, Publicada;
    
}
