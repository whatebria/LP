
import clases.Autor;
import clases.Estado;
import clases.Memoria;
import clases.Paper;
import clases.Publicacion;
import clases.Repositorio;

public class main {
    
    public static void main(String[] args) {

        Repositorio registro = new Repositorio();
        
        Autor autor1 = new Autor("Francisco", "Vera");
        Memoria memoria1 =  new Memoria("Ingenieria en infromatica", "SISTEMA DE GESTION EDUCATIVA", 2023, autor1, Estado.Publicada);
        registro.add(memoria1);
        
        Autor autor2 = new Autor("Alejandro", "Fuentes");
        Paper paper1 = new Paper("Abril 2022", "Revista centro de informacion tecnologica", "MODELO DE PLANIFICACION DE CAMBIOS", 2021, autor2, Estado.Pendiente );
        registro.add(paper1);
        
        Autor autor3 = new Autor("Carolina", "Aliaga");
        Memoria memoria2 = new Memoria("Ingenieria en informatica", "PROPUESTA DE IMPLEMENTACION DE WEB SERVER LOCAL", 2022, autor3, Estado.Autorizada);
        registro.add(memoria2);
        
        Autor autor4 = new Autor("Andrea", "Riquelme");
        Paper paper2 = new Paper("Marzo 2023","Revista perspeciva editorial", "MODELO DE EVALUACION POR COMPETENCIAS", 2023, autor4, Estado.Autorizada);
        registro.add(paper2);
        
        Autor autor5 = new Autor("Rodrigo", "Alegria");
        Memoria memoria3 = new Memoria("Tecnico universitario en informatica", "SISTEMA DE CONTROL DE STOCK", 2023, autor5, Estado.Publicada);
        registro.add(memoria3);
        
        System.out.println("TODAS LAS PUBLICACIONES:");

        for(Publicacion publicaciones: registro.getPublicaciones()){
            System.out.println(publicaciones);
        }
        
        System.out.println("\nPUBLICACIONES AUN NO PULICADAS");
        for(Publicacion publicaciones: registro.getPublicacionensByEstado(Estado.Autorizada)){
            System.out.println(publicaciones);
        }

        for(Publicacion publicaciones : registro.getPublicacionensByEstado(Estado.Pendiente)){
            System.out.println(publicaciones);
        }
        
        System.out.println("\nPUBLICACIONES DE ESTE AÑO");

        for(Publicacion publicaciones : registro.getPublicacionensByAño(2023)){
            System.out.println(publicaciones);
        }
    }
}
